"""8mem: agent memory your AI can finally keep."""

__all__ = ["__version__"]
__version__ = "0.1.10"
