"""Package resources for 8mem."""
