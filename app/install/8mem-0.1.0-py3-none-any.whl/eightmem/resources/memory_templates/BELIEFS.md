# BELIEFS

Inferred patterns and likely traits based on recurring evidence.

## Entries

- (empty)
