# PREFERENCES

Stable response and formatting preferences.

## Entries

- (empty)
